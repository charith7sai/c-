#include<stdio.h>
int  binary_search(int *arr,int l,int r,int key)
{
    if(l<=r)
    {
        int mid=(l+r)/2;
        if(key==arr[mid])
        return mid;
        else if(key>arr[mid])
        return binary_search(arr,mid+1,r,key);
        else
        return binary_search(arr,l,mid-1,key);
    }
    else
    return -1;
}
void insertion_sort(int *arr,int n)
{
   int i,j,key;
   for(i=1;i<n;i++)
   {
       key=arr[i];
       j=i-1;
       while(j>0&&arr[j]>key)
       {
           arr[j+1]=arr[j];
           j=j-1;
       }
       arr[j+1]=key;
   }
}
int main()
{
    int n;
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    int key;
    scanf("%d",&key);
    insertion_sort(arr,n);
    int res=binary_search(arr,0,n-1,key);
    if(res==-1)
    printf("key not found");
    else
    printf("key found at index %d",res);
    return 0;
}