#include<stdio.h>
int main()
{
    int arr[]={1,2,3,4,5};
    printf("%ld",sizeof(arr)/sizeof(arr[0]));
    return 0;
}
