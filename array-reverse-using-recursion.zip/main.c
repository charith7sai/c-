#include<stdio.h>
void reversearray(int *arr,int n)
{
    if(n<0)
    return ;
    printf("%d",arr[n]);
    reversearray(arr,n-1);
}
int main()
{
    int n;
    scanf("%d",&n);
    int arr[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    reversearray(arr,n-1);
    return 0;
}