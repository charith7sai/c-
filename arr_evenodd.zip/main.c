#include<stdio.h>
int main()
{
    int n,even=0,odd=0;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
     for(int i=0;i<n;i++)
    {
        if(a[i]%2==0)
        {
            even+=a[i];
            
        }
        else
        {
            
            odd+=a[i];
        }
    }
    printf("Even sum is %d",even);
    printf("\nOdd sum is %d",odd);
    return 0;
}
