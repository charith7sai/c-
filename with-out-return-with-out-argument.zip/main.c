#include<stdio.h>
void addition()
{
    int a,b;
    scanf("%d%d",&a,&b);
    int c=a+b;
    printf("%d",c);
}
int main()
{
    addition();
    return 0;
}