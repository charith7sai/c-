#include<stdio.h>
void addition(int a,int b)
{
    int c=a+b;
    printf("%d",c);
}
int main()
{
    int a,b;
    scanf("%d%d",&a,&b);
    addition(a,b);
    return 0;
}