#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *head;
void beginsert();
void main()
{
    void beginsert()
    {
        struct node *ptr;
        int item;
        ptr = (struct node *)malloc(sizeof(struct node *));
        if(ptr == NULL)
        {
            printf("Overflow");
        }
        else
        {
            printf("Enter value");
            scanf("%d",&item);
            ptr->data = item;
            ptr->next = head;
            head=ptr;
            printf("Node inserted");
        }
    }
void display()
{
  struct node *ptr;
  ptr = head;
  if(ptr == NULL)
  {
      printf("nothing to print");
  }
  else
  {
      printf("\n printing values ....... ");
      while(ptr!=NULL)
      {
          printf("%d",ptr->data);
          ptr = ptr->next;
      }
  }
}
    beginsert();
    beginsert();
    beginsert();
}