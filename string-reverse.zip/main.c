#include<stdio.h>
#include<string.h>
int main()
{
    char str1[100],str2[50];
    scanf("%s",str2);
    printf("%s",str2);
    int i,j;
    for(i=0,j=strlen(str2)-1;j>=0;i++,j--)
    {
        str1[i]=str2[j];
    } 
    str1[i]='\0';
    printf("\n %s %s",str1,str2);
    return 0;
}