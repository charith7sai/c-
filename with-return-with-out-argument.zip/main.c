#include<stdio.h>
int addition()
{
    int a,b;
    scanf("%d%d",&a,&b);
    int c=a+b;
    return c;
}
int main()
{
    int res =addition();
    printf("%d",res);
    return 0;
}

