#include<stdio.h>
#include<string.h>
int main()
{
char str[50];
scanf("%[^\n]s",str);
int count=0,sum=0,consonants=0,specialchars=0;
for(int i=0;str[i]!='\0';i++)
{
    if((str[i]>='a'&&str[i]<='z')||(str[i]<='A'&&str[i]>='z'))
    {
    if(str[i]=='A'||str[i]=='E'||str[i]=='I'||str[i]=='O'||str[i]=='U'||str[i]=='u'||str[i]=='a'||str[i]=='e'||str[i]=='i'||str[i]=='o')
    {
        count++;
    }
    else
    {
        consonants++;
    }
    }
else if(str[i]>='0'&&str[i]<='9')
{
    sum++;
}
else
{
   specialchars++; 
}
}
printf("%d\n",count);
printf("%d\n",consonants);
printf("%d\n",sum);
printf("%d",specialchars);
return 0;
}
