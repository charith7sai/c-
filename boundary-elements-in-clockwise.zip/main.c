#include <stdio.h>
int main()
{
    int arr[3][3] = {{1, 2, 3},
                     {4, 5, 6},
                     {7, 8, 9} };
    int i, j;
    printf("The boundary elements of the 2D array in clockwise direction are:\n");
    for (i = 0; i < 3; i++)
    {
        printf("%d ", arr[i][0]);
    }

    for (j = 1; j < 3; j++)
    {
        printf("%d ", arr[2][j]);
    }

    for (i = 2; i >= 0; i--)
    {
        printf("%d ", arr[i][2]);
    }

    for (j = 1; j > 0; j--)
    {
        printf("%d ", arr[0][j]);
    }

    printf("\n");

    return 0;
}
