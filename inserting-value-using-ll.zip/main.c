#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *head;
void beginsert();
void main()
{
    void beginsert()
    {
        struct node *ptr;
        int item;
        ptr = (struct node *)malloc(sizeof(struct node *));
        if(ptr == NULL)
        {
            printf("Overflow");
        }
        else
        {
            printf("Enter value");
            scanf("%d",&item);
            ptr->data = item;
            ptr->next = head;
            head=ptr;
            printf("Node inserted");
        }
    }
    beginsert();
    beginsert();
    beginsert();
    printf("\n%d",head->next->data);

}