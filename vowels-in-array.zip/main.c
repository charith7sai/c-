#include<stdio.h>
#include<string.h>
int main()
{
char str[50];
scanf("%[^\n]s",str);
int count=0,sum=0,consonants=0,special chars=0;
for(int i=0;str[i]!='\0';i++)
{
    if(str[i]=='A'||str[i]=='E'||str[i]=='I'||str[i]=='O'||str[i]=='U'||str[i]=='u'||str[i]=='a'||str[i]=='e'||str[i]=='i'||str[i]=='o')
    {
        count++;
    }
}
printf("%d",count);
return 0;
}
