
#include <stdio.h>

int main()
{
   int n,x;
   scanf("%d",&n);
   int a[n];
   for(int i=0;i<n;i++)
   {
       scanf("%d",&a[i]);
   }
    printf("Enter the number to be search\n");
   scanf("%d",&x);
   for(int i=0;i<n;i++)
   {
       if(a[i]==x)
       {
           printf("Number found");
           return 0;
       }
   }
    printf("Number not found"); 
   
   return 0;
}

