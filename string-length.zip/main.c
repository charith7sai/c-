#include<stdio.h>
int main()
{
    char str[50];
    scanf("%s",str);
    int i=0,len=0;
    while(str[i++]!='\0')
    {
        len ++;
    }
    printf("%d",len);
    return 0;
}